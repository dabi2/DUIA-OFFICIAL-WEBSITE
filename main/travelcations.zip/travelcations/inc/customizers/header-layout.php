<?php
/**
 * Header Contact Customizer
 *
 * @package Travelcations
 */


Travelcations_Kirki::add_section(
	'travelcations_header_layout1',
	array(
		'title' => esc_html__( 'Header Top Bar', 'travelcations' ),
		'panel' => 'travelcations_panel',
	)
);

/**
 * Top Bar
 */

Travelcations_Kirki::add_field(
	'travelcations',
	array(
		'type'     => 'switch',
		'settings' => 'topbar',
		'label'    => esc_html__( 'Topbar', 'travelcations' ),
		'section'  => 'travelcations_header_layout1',
		'default'  => '0',
		'priority' => 10,
		'choices'  => array(
			'on'  => esc_html__( 'Enable', 'travelcations' ),
			'off' => esc_html__( 'Disable', 'travelcations' ),
		),
	)
);

Travelcations_Kirki::add_field(
	'travelcations',
	array(
		'type'        => 'editor',
		'settings'    => 'phone-default',
		'label'       => esc_html__( 'Mobile', 'travelcations' ),
		'description' => esc_html__( 'Enter Mobie.', 'travelcations' ),
		'section'     => 'travelcations_header_layout1',
		'transport'   => 'auto',
	)
);


Travelcations_Kirki::add_field(
	'travelcations',
	array(
		'type'      => 'editor',
		'settings'  => 'header_contact',
		'label'     => esc_html__( 'Contact', 'travelcations' ),
		'section'   => 'travelcations_header_layout1',
		'default'   => '',
		'transport' => 'auto',
	)
);

Travelcations_Kirki::add_field(
	'travelcations',
	array(
		'type'      => 'editor',
		'settings'  => 'header_right',
		'label'     => esc_html__( 'Top Bar Right', 'travelcations' ),
		'section'   => 'travelcations_header_layout1',
		'default'   => '',
		'transport' => 'auto',
	)
);

