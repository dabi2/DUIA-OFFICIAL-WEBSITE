<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<?php travelcations_post_thumbnail(); ?>

	<div class="blog-detail">
		<header class="blog-header">


			<?php the_title( '<h2 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h2>' ); ?>
		</header><!-- .entry-header -->


			<div class="entry-summary">
				<?php the_excerpt(); ?>
			</div>

	</div>


</article><!-- #post-<?php the_ID(); ?> -->