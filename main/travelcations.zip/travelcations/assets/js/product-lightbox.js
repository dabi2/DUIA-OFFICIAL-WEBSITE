(function ($) {

    'use strict';

	var html5lightbox_options = {
		watermark: "http://html5box.com/images/html5boxlogo.png",
		watermarklink: ""
	};
})(jQuery);

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiIiwic291cmNlcyI6WyJwcm9kdWN0LWxpZ2h0Ym94LmpzIl0sInNvdXJjZXNDb250ZW50IjpbIihmdW5jdGlvbiAoJCkge1xuXG4gICAgJ3VzZSBzdHJpY3QnO1xuXG5cdHZhciBodG1sNWxpZ2h0Ym94X29wdGlvbnMgPSB7XG5cdFx0d2F0ZXJtYXJrOiBcImh0dHA6Ly9odG1sNWJveC5jb20vaW1hZ2VzL2h0bWw1Ym94bG9nby5wbmdcIixcblx0XHR3YXRlcm1hcmtsaW5rOiBcIlwiXG5cdH07XG59KShqUXVlcnkpO1xuIl0sImZpbGUiOiJwcm9kdWN0LWxpZ2h0Ym94LmpzIn0=
